"""
to_tim_filtr.py - отбор качественных изображений ядер (отсев расфокуса).

Самодостаточный скрипт: на вход директория с картинками, где каждый файл -
одно вырезанное ядро (фон = 0). Для каждого ядра считаются метрики резкости
и текстуры, по ним строится HTML-отчёт для подбора порогов, а затем таблица
со статусом PASS / REJECTED.

Метрики (все считаются ВНУТРИ маски ядра, т.е. по ненулевым пикселям):
  laplacian_variance - дисперсия лапласиана. Главная метрика резкости:
                       расфокус даёт низкое значение.
  std_intensity      - стандартное отклонение яркости внутри ядра.
  fourier_hf_ratio   - доля энергии в высоких частотах спектра.
                       Направление зависит от данных (шум расфокуса тоже
                       высокочастотный) - смотрите линейку в HTML.
  roughness_Ra       - среднее абсолютное отклонение яркости (шероховатость).
  roughness_Rq       - RMS-шероховатость.

----------------------------------------------------------------------------
ИСПОЛЬЗОВАНИЕ
----------------------------------------------------------------------------
  1) Посмотреть на данные и подобрать пороги:

       python to_tim_filtr.py html /path/to/nuclei

     Считает метрики и делает nuclei_quality_report.html рядом с этим
     скриптом. Пороги в отчёте не применяются - чистые распределения и
     примеры ядер по диапазонам каждой метрики. CSV не создаётся.

  2) Открыть HTML, посмотреть, с какого значения начинается расфокус,
     прописать пороги в блоке THRESHOLDS ниже, затем:

       python to_tim_filtr.py filter_after_html /path/to/nuclei

     Метрики берутся из кэша от шага 1 (не пересчитываются), HTML
     перерисовывается уже с линиями порогов и подсветкой отбракованных
     ячеек, и создаётся таблица nuclei_quality.csv.

  3) Либо сразу, одной командой (метрики считаются заново):

       python to_tim_filtr.py filter /path/to/nuclei

Дополнительные флаги:
  --out DIR      куда класть результаты (по умолчанию - папка со скриптом)
  --recursive    искать картинки и во вложенных папках

Зависимости: numpy, pandas, opencv-python, scipy, matplotlib (tqdm - опционально).
"""

import argparse
import base64
import html as html_mod
import io
import random
import sys
from itertools import combinations
from pathlib import Path

import cv2
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.ndimage import binary_erosion

try:
    from tqdm import tqdm
except ImportError:  # tqdm необязателен
    def tqdm(it, **kwargs):
        return it


# --------------------------------------------------------------------------
#
#   ПОРОГИ - ЕДИНСТВЕННОЕ, ЧТО НУЖНО ПРАВИТЬ РУКАМИ
#
#   Формат каждого порога - пара (min, max):
#
#     (5.0,  None)  ядро REJECTED, если метрика < 5.0        (отсекаем слева)
#     (None, 0.21)  ядро REJECTED, если метрика > 0.21       (отсекаем справа)
#     (5.0,  100.0) ядро REJECTED, если метрика < 5 ИЛИ > 100 (интервал)
#     None          метрика не участвует в фильтрации
#
#   Ядро получает REJECTED, если оно не прошло ХОТЯ БЫ ПО ОДНОЙ метрике
#   (объединение условий). В колонке rejected_by видно, по каким именно.
#
#   Значения ниже - стартовые, снятые с конкретного микроскопа. Для своих
#   снимков их почти наверняка надо переподобрать по HTML-отчёту.
#
# --------------------------------------------------------------------------

THRESHOLDS = {
    # Резкость: чем меньше, тем сильнее расфокус - отсекаем снизу.
    "laplacian_variance": (None, None),

    # Контраст внутри ядра - отсекаем снизу.
    "std_intensity":      (None,  44),

    # Доля высоких частот. Считается по центрированному внутри маски
    # изображению с окном Ханна. Направление НЕ универсально: структура
    # хроматина тянет её вверх, но и шум расфокуса тоже. Обязательно
    # посмотрите линейку Fourier HF в HTML и решите, с какой стороны
    # резать; здесь порог унаследован сверху.
    "fourier_hf_ratio":   (None,  0.1),

    # Шероховатость (выраженность текстуры хроматина): отсекаем снизу.
    "roughness_Ra":       (None, 35),
    "roughness_Rq":       (None , 45),
}

# --- Параметры расчёта метрик ---
LAPLACIAN_KSIZE = 5   # размер ядра оператора Лапласа
SHRINK_BY = 5         # эрозия маски ядра на N пикселей: убирает краевые
                      # артефакты на границе ядро/фон, которые иначе дают
                      # ложно высокую резкость
FOURIER_CUTOFF = 0.3  # радиус «низких частот» как доля от полуразмера спектра

# --- Имена выходных файлов (кладутся в --out, по умолчанию рядом со скриптом) ---
HTML_NAME = "nuclei_quality_report.html"
CSV_NAME = "nuclei_quality.csv"
CACHE_NAME = ".nuclei_metrics_cache.pkl"   # служебный кэш метрик между запусками

SUPPORTED_EXT = {".tif", ".tiff", ".png", ".jpg", ".jpeg", ".bmp"}


# --------------------------------------------------------------------------
#  МЕТРИКИ
# --------------------------------------------------------------------------

def compute_nucleus_metrics(img, ksize=LAPLACIAN_KSIZE, shrink_by=SHRINK_BY):
    """Резкость и контраст внутри маски ядра (ненулевые пиксели)."""
    mask = img > 0

    if shrink_by > 0:
        struct = np.ones((2 * shrink_by + 1, 2 * shrink_by + 1), dtype=bool)
        eroded = binary_erosion(mask, structure=struct)
        # Если эрозия «съела» всё ядро - используем исходную маску.
        if eroded.any():
            mask = eroded

    pixels = img[mask]
    if len(pixels) == 0:
        return {"laplacian_variance": 0.0, "std_intensity": 0.0, "n_pixels": 0}

    lap = cv2.Laplacian(img, cv2.CV_64F, ksize=ksize)

    return {
        "laplacian_variance": float(lap[mask].var()),
        "std_intensity": float(pixels.astype(np.float64).std()),
        "n_pixels": int(len(pixels)),
    }


def fourier_high_freq_ratio(img, cutoff_fraction=FOURIER_CUTOFF):
    """
    Доля энергии высокочастотной части спектра.

    Маска ядра + окно Ханна обязательны: без них FFT доминируется резким
    перепадом на границе ядро/фон, и все ядра получают почти одинаковые
    значения.
    """
    mask = img > 0
    if not mask.any():
        return 0.0

    img_f = img.astype(np.float64)
    img_centered = np.where(mask, img_f - img_f[mask].mean(), 0.0)

    rows, cols = img.shape
    window = np.outer(np.hanning(rows), np.hanning(cols))
    f = np.fft.fftshift(np.fft.fft2(img_centered * window))
    magnitude = np.abs(f) ** 2

    crow, ccol = rows // 2, cols // 2
    r = int(min(crow, ccol) * cutoff_fraction)
    Y, X = np.ogrid[:rows, :cols]
    low_mask = ((X - ccol) ** 2 + (Y - crow) ** 2) <= r ** 2

    total = magnitude.sum()
    return float(magnitude[~low_mask].sum() / total) if total > 0 else 0.0


def surface_roughness(img):
    """Ra (среднее абс. отклонение) и Rq (RMS) яркости внутри ядра."""
    pixels = img[img > 0].astype(np.float64)
    if len(pixels) == 0:
        return 0.0, 0.0
    deviations = pixels - pixels.mean()
    return float(np.abs(deviations).mean()), float(np.sqrt((deviations ** 2).mean()))


def list_images(directory, recursive=False):
    d = Path(directory)
    if not d.is_dir():
        sys.exit(f"ОШИБКА: не директория: {d}")
    it = d.rglob("*") if recursive else d.iterdir()
    files = [f for f in it
             if f.is_file()
             and f.suffix.lower() in SUPPORTED_EXT
             and not f.name.startswith(".")]
    if not files:
        sys.exit(f"ОШИБКА: в {d} нет изображений "
                 f"({', '.join(sorted(SUPPORTED_EXT))})"
                 + ("" if recursive else "; попробуйте --recursive"))
    return sorted(files)


def compute_all_metrics(directory, recursive=False, verbose=True):
    """Пройти по всем картинкам директории и собрать таблицу метрик."""
    files = list_images(directory, recursive)
    if verbose:
        print(f"Найдено изображений: {len(files)}")

    records, n_failed = [], 0
    for fpath in tqdm(files, desc="Метрики", disable=not verbose):
        img = cv2.imread(str(fpath), cv2.IMREAD_GRAYSCALE)
        if img is None:
            n_failed += 1
            continue

        Ra, Rq = surface_roughness(img)
        records.append({
            "filename": fpath.name,
            "path": str(fpath.resolve()),
            **compute_nucleus_metrics(img),
            "fourier_hf_ratio": fourier_high_freq_ratio(img),
            "roughness_Ra": Ra,
            "roughness_Rq": Rq,
        })

    if n_failed and verbose:
        print(f"  ПРЕДУПРЕЖДЕНИЕ: не удалось прочитать файлов: {n_failed}")
    if not records:
        sys.exit("ОШИБКА: не удалось прочитать ни одного изображения.")

    df = pd.DataFrame(records)
    if verbose:
        print(f"Посчитано ядер: {len(df)}")
    return df


# --------------------------------------------------------------------------
#  ФИЛЬТРАЦИЯ
# --------------------------------------------------------------------------

def _bounds(thr):
    """Нормализовать порог к паре (lo, hi). None даёт (None, None)."""
    if thr is None:
        return None, None
    if isinstance(thr, (int, float)):
        return float(thr), None
    if isinstance(thr, (tuple, list)) and len(thr) == 2:
        return thr[0], thr[1]
    raise ValueError(f"Неверный формат порога: {thr!r}. Ожидается (min, max).")


def active_thresholds(thresholds=None):
    """Только те пороги, которые заданы и метрика которых существует."""
    thresholds = THRESHOLDS if thresholds is None else thresholds
    out = {}
    for metric, thr in thresholds.items():
        lo, hi = _bounds(thr)
        if lo is not None or hi is not None:
            out[metric] = (lo, hi)
    return out


def apply_thresholds(df, thresholds=None, verbose=True):
    """
    Пометить каждое ядро как PASS / REJECTED.

    Добавляет колонки:
      quality_status - PASS или REJECTED
      rejected_by    - через запятую метрики, по которым ядро не прошло

    Возвращает (df, stats) - stats это таблица отбраковки по метрикам.
    """
    df = df.copy()
    thr_active = active_thresholds(thresholds)

    n_total = len(df)
    rejected_any = pd.Series(False, index=df.index)
    reasons = pd.Series([[] for _ in range(n_total)], index=df.index)
    stats_rows = []

    for metric, (lo, hi) in thr_active.items():
        if metric not in df.columns:
            if verbose:
                print(f"  ПРЕДУПРЕЖДЕНИЕ: метрики {metric} нет в таблице, пропускаю")
            continue

        mask_bad = pd.Series(False, index=df.index)
        desc = []
        if lo is not None:
            mask_bad |= df[metric] < lo
            desc.append(f"≥ {lo:.4g}")
        if hi is not None:
            mask_bad |= df[metric] > hi
            desc.append(f"≤ {hi:.4g}")

        rejected_any |= mask_bad
        for idx in df.index[mask_bad]:
            reasons[idx].append(metric)

        n_bad = int(mask_bad.sum())
        stats_rows.append({
            "metric": metric,
            "keep_if": " и ".join(desc),
            "rejected": n_bad,
            "total": n_total,
            "rejected_pct": round(100 * n_bad / max(n_total, 1), 2),
        })

    df["quality_status"] = np.where(rejected_any, "REJECTED", "PASS")
    df["rejected_by"] = reasons.apply(lambda r: ",".join(r))

    n_rej = int(rejected_any.sum())
    stats_rows.append({
        "metric": "ВСЕГО (объединение)",
        "keep_if": "",
        "rejected": n_rej,
        "total": n_total,
        "rejected_pct": round(100 * n_rej / max(n_total, 1), 2),
    })
    stats = pd.DataFrame(stats_rows)

    if verbose:
        if not thr_active:
            print("\n  ВНИМАНИЕ: ни один порог не задан - все ядра PASS.")
        print("\nСтатистика отбраковки:")
        print(stats.to_string(index=False))
        print(f"\nИтог: PASS {n_total - n_rej}/{n_total} "
              f"({100 * (n_total - n_rej) / max(n_total, 1):.1f}%), "
              f"REJECTED {n_rej}")
        print("  (ВСЕГО - объединение по метрикам, поэтому оно может быть "
              "меньше суммы строк выше: одно ядро может нарушать несколько порогов)")

    return df, stats


# --------------------------------------------------------------------------
#  HTML-ОТЧЁТ
# --------------------------------------------------------------------------

GRID = 12               # размер 2D-сетки (12×12)
EXAMPLES_PER_CELL = 6   # примеров в ячейке 2D-сетки
THUMB_SIZE = 130
STRIP_BINS = 12         # участков в 1D-линейке
STRIP_EXAMPLES = 8      # примеров на участок линейки

METRIC_COLS = ["laplacian_variance", "std_intensity",
               "fourier_hf_ratio", "roughness_Ra", "roughness_Rq"]

METRIC_LABELS = {
    "laplacian_variance": "Laplacian var",
    "std_intensity": "Std intensity",
    "fourier_hf_ratio": "Fourier HF",
    "roughness_Ra": "Roughness Ra",
    "roughness_Rq": "Roughness Rq",
}

SHORT = {
    "laplacian_variance": "lap",
    "std_intensity": "std",
    "fourier_hf_ratio": "fft",
    "roughness_Ra": "Ra",
    "roughness_Rq": "Rq",
}


def _afmt(v):
    """Адаптивное форматирование: больше знаков для маленьких значений."""
    av = abs(v) if v != 0 else 1.0
    if av < 0.01:
        return f"{v:.5f}"
    if av < 1:
        return f"{v:.4f}"
    if av < 100:
        return f"{v:.2f}"
    return f"{v:.1f}"


def _bin_label(lo, hi):
    diff = abs(hi - lo)
    if diff == 0:
        return f"≈ {lo:.6g}"
    if diff < 1e-5:
        return f"{lo:.6f} - {hi:.6f}"
    if diff < 1e-3:
        return f"{lo:.5f} - {hi:.5f}"
    if diff < 0.01:
        return f"{lo:.4f} - {hi:.4f}"
    return f"{_afmt(lo)} - {_afmt(hi)}"


def _format_thr_text(thr):
    lo, hi = _bounds(thr)
    parts = []
    if lo is not None:
        parts.append(f"≥ {lo:.4g}")
    if hi is not None:
        parts.append(f"≤ {hi:.4g}")
    return " и ".join(parts) if parts else "(не задан)"


def _count_rejected(df, col, thr):
    lo, hi = _bounds(thr)
    if lo is None and hi is None:
        return 0
    mask = pd.Series(False, index=df.index)
    if lo is not None:
        mask |= df[col] < lo
    if hi is not None:
        mask |= df[col] > hi
    return int(mask.sum())


def _value_rejected(value, thr):
    lo, hi = _bounds(thr)
    if lo is not None and value < lo:
        return True
    if hi is not None and value > hi:
        return True
    return False


def img_to_datauri(img, max_side=THUMB_SIZE):
    if img is None:
        return ""
    h, w = img.shape[:2]
    if max(h, w) > max_side:
        scale = max_side / max(h, w)
        img = cv2.resize(img, (max(int(w * scale), 1), max(int(h * scale), 1)),
                         interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".png", img)
    if not ok:
        return ""
    return f"data:image/png;base64,{base64.b64encode(buf).decode('ascii')}"


def fig_to_datauri(fig, dpi=130):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    buf.seek(0)
    return f"data:image/png;base64,{base64.b64encode(buf.read()).decode('ascii')}"


def _robust_quantile_edges(values, n_bins):
    """
    Квантильные границы бинов, устойчивые к повторяющимся значениям.

    np.percentile даёт одинаковые границы, если данные сильно
    сконцентрированы; тогда откатываемся на равномерное разбиение.
    """
    edges = np.percentile(values, np.linspace(0, 100, n_bins + 1))
    unique_edges = np.unique(edges)
    if len(unique_edges) >= n_bins + 1:
        idx = np.linspace(0, len(unique_edges) - 1, n_bins + 1).astype(int)
        return unique_edges[idx]
    lo, hi = float(np.min(values)), float(np.max(values))
    if lo == hi:
        hi = lo + 1e-9
    return np.linspace(lo, hi, n_bins + 1)


def _metrics_line(row, available):
    parts = []
    for m in available:
        v = row.get(m, float("nan"))
        s = SHORT.get(m, m[:3])
        parts.append(f"{s}=-" if np.isnan(v) else f"<b>{s}</b>={v:.4g}")
    return f'<div class="all-metrics">{" ".join(parts)}</div>'


def _thumb(row, max_side):
    img = cv2.imread(str(row.get("path", "")), cv2.IMREAD_GRAYSCALE)
    uri = img_to_datauri(img, max_side=max_side) if img is not None else ""
    return f'<img src="{uri}" />' if uri else ""


def build_1d_strip(df, col, thresholds, available, strip_id):
    """1D-линейка: STRIP_BINS участков слева направо, от минимума к максимуму."""
    vals = df[col].dropna().values
    if len(vals) == 0:
        return ""
    label = METRIC_LABELS.get(col, col)
    thr = thresholds.get(col)

    edges = _robust_quantile_edges(vals, STRIP_BINS)
    bin_idx = np.clip(np.digitize(df[col].values, edges, right=False) - 1,
                      0, STRIP_BINS - 1)
    members = {}
    for i, b in enumerate(bin_idx):
        members.setdefault(b, []).append(df.index[i])

    html = f'<div class="strip-section" id="strip_{strip_id}">'
    html += f'<h3>{label}</h3>'
    if thr is not None:
        n_bad = _count_rejected(df, col, thr)
        html += (f'<p class="thr-info">Порог (оставляем): <b>{_format_thr_text(thr)}</b>'
                 f' | отбраковано: {n_bad} ({100 * n_bad / len(df):.1f}%)</p>')
    html += ('<p class="strip-help">Значения растут слева направо. В каждой ячейке - '
             'примеры ядер из этого диапазона и значения всех метрик. '
             'Красным подсвечены участки, целиком попавшие под отбраковку.</p>')

    html += '<div class="strip-row">'
    for b in range(STRIP_BINS):
        lo, hi = edges[b], edges[min(b + 1, STRIP_BINS)]
        idxs = members.get(b, [])

        # Участок красим, только если он ЦЕЛИКОМ в зоне отбраковки.
        is_rej = False
        if thr is not None:
            lo_t, hi_t = _bounds(thr)
            is_rej = ((lo_t is not None and hi < lo_t)
                      or (hi_t is not None and lo > hi_t))

        html += f'<div class="strip-cell{" rejected" if is_rej else ""}">'
        html += f'<div class="edge-label">{_bin_label(lo, hi)}</div>'
        html += f'<div class="count-label">n={len(idxs)}</div>'

        examples = random.sample(idxs, min(STRIP_EXAMPLES, len(idxs))) if idxs else []
        for idx in examples[:3]:
            row = df.loc[idx]
            html += _thumb(row, 110) + _metrics_line(row, available)

        if len(examples) > 3:
            gid = f"sg_{strip_id}_{b}"
            html += (f'<span class="toggle-btn" onclick="toggle(\'{gid}\')">'
                     f'+{len(examples) - 3} ещё</span>')
            html += f'<div class="gallery" id="{gid}">'
            for idx in examples[3:]:
                html += _thumb(df.loc[idx], 100)
            html += '</div>'
        html += '</div>'
    html += '</div></div>'
    return html


def make_heatmap(df, x_col, y_col, title, thr_x=None, thr_y=None):
    x_edges = _robust_quantile_edges(df[x_col].values, GRID)
    y_edges = _robust_quantile_edges(df[y_col].values, GRID)

    x_idx = np.clip(np.digitize(df[x_col].values, x_edges, right=False) - 1, 0, GRID - 1)
    y_idx = np.clip(np.digitize(df[y_col].values, y_edges, right=False) - 1, 0, GRID - 1)

    counts = np.zeros((GRID, GRID), dtype=int)
    members = {}
    for i, (xi, yi) in enumerate(zip(x_idx, y_idx)):
        counts[yi, xi] += 1
        members.setdefault((xi, yi), []).append(df.index[i])

    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(np.log1p(counts), origin="lower", aspect="auto", cmap="viridis")
    plt.colorbar(im, ax=ax, label="log(1 + count)")

    ax.set_xticks(range(GRID + 1))
    ax.set_xticklabels([_afmt(v) for v in x_edges], fontsize=6, rotation=45, ha="right")
    ax.set_yticks(range(GRID + 1))
    ax.set_yticklabels([_afmt(v) for v in y_edges], fontsize=6)

    xl = METRIC_LABELS.get(x_col, x_col)
    yl = METRIC_LABELS.get(y_col, y_col)
    has_legend = False

    def _draw(thr, edges, axis_label, is_x):
        nonlocal has_legend
        lo_t, hi_t = _bounds(thr)
        fn = ax.axvline if is_x else ax.axhline
        lo_color, hi_color = ("red", "darkred") if is_x else ("orange", "darkorange")
        for val, color, name in ((lo_t, lo_color, "min"), (hi_t, hi_color, "max")):
            if val is None:
                continue
            fn(np.searchsorted(edges, val) - 0.5, color=color, linewidth=2,
               label=f"{name} {axis_label}={val:.4g}")
            has_legend = True

    _draw(thr_x, x_edges, xl, is_x=True)
    _draw(thr_y, y_edges, yl, is_x=False)

    ax.set_xlabel(xl)
    ax.set_ylabel(yl)
    ax.set_title(title)
    if has_legend:
        ax.legend(fontsize=8)
    return fig, members, x_edges, y_edges


def build_grid_html(df, members, x_edges, y_edges, thresholds,
                    x_col, y_col, available, pair_id):
    """Сетка GRID×GRID: в каждой ячейке пример ядра и все метрики."""
    selected = {}
    for key, idxs in members.items():
        selected[key] = (idxs if len(idxs) <= EXAMPLES_PER_CELL
                         else random.sample(idxs, EXAMPLES_PER_CELL))

    thr_x = thresholds.get(x_col)
    thr_y = thresholds.get(y_col)

    grid_html = '<div class="grid"><div class="row"><div class="axis-corner"></div>'
    for ix in range(GRID):
        grid_html += (f'<div class="axis-label">{_afmt(x_edges[ix])}<br>-<br>'
                      f'{_afmt(x_edges[min(ix + 1, GRID)])}</div>')
    grid_html += '</div>'

    for iy in range(GRID - 1, -1, -1):
        grid_html += (f'<div class="row"><div class="axis-label-y">'
                      f'{_afmt(y_edges[iy])}<br>-<br>'
                      f'{_afmt(y_edges[min(iy + 1, GRID)])}</div>')

        for ix in range(GRID):
            cell_members = members.get((ix, iy), [])
            cell_examples = selected.get((ix, iy), [])

            x_mid = (x_edges[ix] + x_edges[min(ix + 1, GRID)]) / 2
            y_mid = (y_edges[iy] + y_edges[min(iy + 1, GRID)]) / 2
            is_rejected = (_value_rejected(x_mid, thr_x)
                           or _value_rejected(y_mid, thr_y))

            grid_html += f'<div class="cell{" rejected" if is_rejected else ""}">'
            grid_html += f'<div class="count-label">n={len(cell_members)}</div>'

            if cell_examples:
                row = df.loc[cell_examples[0]]
                grid_html += _thumb(row, THUMB_SIZE) + _metrics_line(row, available)

                if len(cell_examples) > 1:
                    gid = f"g_{pair_id}_{ix}_{iy}"
                    grid_html += (f'<span class="toggle-btn" onclick="toggle(\'{gid}\')">'
                                  f'+{len(cell_examples) - 1} ещё</span>')
                    grid_html += f'<div class="gallery" id="{gid}">'
                    for idx_ex in cell_examples[1:]:
                        r = df.loc[idx_ex]
                        grid_html += _thumb(r, THUMB_SIZE) + _metrics_line(r, available)
                    grid_html += '</div>'
            grid_html += '</div>'
        grid_html += '</div>'
    return grid_html + '</div>'


def make_histograms(df, thresholds, available):
    if not available:
        return None
    fig, axes = plt.subplots(1, len(available), figsize=(5 * len(available), 4))
    if len(available) == 1:
        axes = [axes]

    for ax, col in zip(axes, available):
        vals = df[col].dropna()
        ax.hist(vals, bins=100, alpha=0.7, edgecolor="black", linewidth=0.3)
        ax.set_title(f"{METRIC_LABELS.get(col, col)}\n(n={len(vals)})", fontsize=10)
        ax.set_xlabel(col)

        lo_t, hi_t = _bounds(thresholds.get(col))
        if lo_t is not None:
            ax.axvline(lo_t, color="red", linewidth=2, label=f"min={lo_t:.4g}")
            ax.text(lo_t, ax.get_ylim()[1] * 0.9,
                    f" {int((vals < lo_t).sum())} отбр.", fontsize=7, color="red")
        if hi_t is not None:
            ax.axvline(hi_t, color="orange", linewidth=2, label=f"max={hi_t:.4g}")
            ax.text(hi_t, ax.get_ylim()[1] * 0.8,
                    f" {int((vals > hi_t).sum())} отбр.", fontsize=7, color="orange")
        if lo_t is not None or hi_t is not None:
            ax.legend(fontsize=7)

    fig.suptitle("Распределения метрик" +
                 (" (красная линия - min, оранжевая - max)"
                  if any(thresholds.values()) else ""), fontsize=11)
    plt.tight_layout()
    return fig


CSS = """
body { font-family: Arial, sans-serif; margin: 18px; background: #fafafa; }
.header { display: flex; gap: 20px; align-items: flex-start; flex-wrap: wrap; }
.heatmap { border: 1px solid #ddd; max-width: 750px; }
.histograms { max-width: 100%; margin-top: 10px; }
.stats { background: #fff; border: 1px solid #ddd; padding: 12px; margin: 12px 0;
         border-radius: 4px; font-size: 0.95em; }
.mode-banner { padding: 10px 12px; border-radius: 4px; margin: 10px 0;
               font-size: 0.95em; }
.mode-preview { background: #eef6ff; border: 1px solid #b8d6f5; }
.mode-filter { background: #fff5ee; border: 1px solid #f5cdb8; }
.grid { margin-top: 18px; }
.row { display: flex; gap: 3px; margin-bottom: 3px; }
.cell { width: 145px; min-height: 170px; border: 1px solid #ddd; padding: 3px;
        box-sizing: border-box; text-align: center; background: #fff; font-size: 0.7em; }
.cell.rejected { background: #fff0f0; border-color: #fcc; }
.cell img { max-width: 130px; max-height: 130px; object-fit: contain; display: block;
            margin: 2px auto; }
.axis-label { width: 145px; text-align: center; font-size: 0.65em; color: #555;
              background: #f0f0f0; padding: 2px; box-sizing: border-box; }
.axis-label-y { width: 55px; min-width: 55px; text-align: right; font-size: 0.65em;
                color: #555; padding: 2px 4px 2px 0; display: flex;
                align-items: center; justify-content: flex-end; }
.axis-corner { width: 55px; min-width: 55px; }
.toggle-btn { font-size: 0.8em; color: #06c; cursor: pointer; text-decoration: underline; }
.gallery { display: none; margin-top: 4px; border-top: 1px dashed #eee; padding-top: 4px; }
.gallery img { max-width: 110px; max-height: 110px; margin: 2px; display: inline-block; }
.all-metrics { font-size: 0.7em; color: #444; margin-top: 1px; line-height: 1.3; }
.count-label { font-size: 0.75em; color: #888; }
.section { margin-top: 30px; border-top: 3px solid #333; padding-top: 10px; }
.pair-nav { position: sticky; top: 0; background: #fff; padding: 8px; z-index: 100;
            border-bottom: 1px solid #ddd; }
.pair-nav a { margin-right: 12px; font-size: 0.9em; }
.strip-section { margin: 20px 0; padding: 12px; background: #fff; border: 1px solid #ddd;
                 border-radius: 6px; }
.strip-row { display: flex; gap: 4px; overflow-x: auto; padding: 4px 0; }
.strip-cell { min-width: 135px; max-width: 160px; border: 1px solid #ddd; padding: 4px;
              text-align: center; background: #fafcff; font-size: 0.72em; flex-shrink: 0; }
.strip-cell.rejected { background: #fff0f0; border-color: #fcc; }
.strip-cell img { max-width: 110px; max-height: 110px; object-fit: contain;
                  display: block; margin: 2px auto; }
.edge-label { font-size: 0.75em; color: #333; font-weight: bold; background: #eef;
              padding: 2px; border-radius: 3px; margin-bottom: 3px; }
.thr-info { color: #c00; font-weight: bold; }
.strip-help { font-size: 0.85em; color: #666; }
"""

JS = """
function toggle(id) {
    var el = document.getElementById(id);
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
"""


def build_html_report(df, output_path, thresholds=None, source_dir="",
                      verbose=True):
    """
    Собрать самодостаточный HTML-отчёт.

    thresholds=None: режим просмотра, ни линий, ни подсветки, только
    распределения и примеры. Иначе пороги рисуются и отбракованные
    участки/ячейки красятся.
    """
    show_thr = thresholds is not None
    thr = thresholds or {}

    available = [c for c in METRIC_COLS if c in df.columns and df[c].notna().any()]
    if not available:
        sys.exit("ОШИБКА: в таблице нет ни одной метрики.")

    df_valid = df.dropna(subset=available).reset_index(drop=True)
    n_total = len(df_valid)

    # --- Сводка ---
    stats_parts = [f"<b>Всего ядер:</b> {n_total}"]
    if source_dir:
        stats_parts[0] += f" | <b>Директория:</b> {html_mod.escape(str(source_dir))}"
    for m in available:
        line = f"<b>{METRIC_LABELS.get(m, m)}:</b> "
        if show_thr and thr.get(m) is not None:
            n_bad = _count_rejected(df_valid, m, thr[m])
            line += (f"<span style='color:#c00'>оставляем {_format_thr_text(thr[m])} - "
                     f"отбраковано {n_bad} ({100 * n_bad / max(n_total, 1):.1f}%)</span>")
        else:
            line += (f"<i>порог не задан</i> (min={df_valid[m].min():.4g}, "
                     f"медиана={df_valid[m].median():.4g}, max={df_valid[m].max():.4g})")
        stats_parts.append(line)

    if show_thr:
        n_rej = int((df_valid["quality_status"] == "REJECTED").sum()) \
            if "quality_status" in df_valid.columns else 0
        banner = (f'<div class="mode-banner mode-filter"><b>Режим фильтрации.</b> '
                  f'Пороги применены: PASS {n_total - n_rej}, REJECTED {n_rej}. '
                  f'Красным помечены диапазоны, целиком попадающие под отбраковку. '
                  f'Таблица со статусами - в {CSV_NAME}.</div>')
    else:
        banner = ('<div class="mode-banner mode-preview"><b>Режим просмотра.</b> '
                  'Пороги не применялись. Пролистайте линейки ниже, найдите, '
                  'с какого значения ядра становятся расфокусированными, впишите '
                  'эти числа в блок THRESHOLDS в to_tim_filtr.py и запустите '
                  '<code>python to_tim_filtr.py filter_after_html &lt;папка&gt;</code>.</div>')

    # --- Навигация ---
    nav_items = [f'<a href="#strip_{i}">{METRIC_LABELS.get(c, c)}</a>'
                 for i, c in enumerate(available)]

    pairs = []
    if len(available) >= 2:
        pairs = list(combinations(available, 2))
        # Основную пару (контраст × резкость) - вперёд.
        primary = ("std_intensity", "laplacian_variance")
        for cand in (primary, primary[::-1]):
            if cand in pairs:
                pairs.remove(cand)
                pairs.insert(0, cand)
                break
        nav_items += [f'<a href="#pair_{i}">{METRIC_LABELS.get(x, x)} × '
                      f'{METRIC_LABELS.get(y, y)}</a>'
                      for i, (x, y) in enumerate(pairs)]

    parts = [
        "<!doctype html><html><head><meta charset='utf-8'>",
        "<title>Качество ядер</title>",
        f"<style>{CSS}</style><script>{JS}</script></head><body>",
        "<h1>Отчёт по качеству ядер</h1>",
        banner,
        f'<div class="stats">{"<br>".join(stats_parts)}</div>',
        '<div class="pair-nav"><b>Навигация:</b> ' + " | ".join(nav_items) + '</div>',
    ]

    hist_fig = make_histograms(df_valid, thr if show_thr else {}, available)
    if hist_fig is not None:
        parts.append(f'<img class="histograms" src="{fig_to_datauri(hist_fig)}"/>')

    parts.append('<h2>Одномерные линейки</h2>')
    parts.append(f'<p>Каждая линейка - один признак, разбитый на {STRIP_BINS} участков, '
                 'равных по числу ядер. Так подбирается порог по каждому признаку '
                 'отдельно.</p>')
    for i, col in enumerate(available):
        if verbose:
            print(f"  линейка: {METRIC_LABELS.get(col, col)}")
        parts.append(build_1d_strip(df_valid, col, thr if show_thr else {},
                                    available, i))

    if pairs:
        parts.append('<h2>Тепловые карты (пары метрик)</h2>')
        parts.append('<p>Для подбора комбинированных порогов. Числовые границы '
                     'подписаны на каждой полосе.</p>')

    for i, (xc, yc) in enumerate(pairs):
        xl, yl = METRIC_LABELS.get(xc, xc), METRIC_LABELS.get(yc, yc)
        if verbose:
            print(f"  карта {i + 1}/{len(pairs)}: {xl} × {yl}")

        hfig, members, xe, ye = make_heatmap(
            df_valid, xc, yc, f"{yl} vs {xl}",
            thr_x=thr.get(xc) if show_thr else None,
            thr_y=thr.get(yc) if show_thr else None,
        )
        grid = build_grid_html(df_valid, members, xe, ye,
                               thr if show_thr else {}, xc, yc, available, i)
        parts.append(f"""
        <div class="section" id="pair_{i}">
            <h2>{xl} × {yl}</h2>
            <div class="header"><img class="heatmap" src="{fig_to_datauri(hfig)}"/></div>
            <h3>Сетка: {xl} слева направо, {yl} снизу вверх</h3>
            <p>Нажмите «+N ещё», чтобы раскрыть остальные примеры ячейки.</p>
            {grid}
        </div>""")

    parts.append("</body></html>")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("".join(parts), encoding="utf-8")
    if verbose:
        print(f"HTML: {output_path} "
              f"({output_path.stat().st_size / 1024 / 1024:.1f} МБ)")


# --------------------------------------------------------------------------
#  CLI
# --------------------------------------------------------------------------

def load_cached_metrics(cache_path, images_dir, verbose=True):
    """Метрики из кэша предыдущего запуска; None, если кэш неприменим."""
    cache_path = Path(cache_path)
    if not cache_path.exists():
        print("  Готовых метрик нет (режим html здесь ещё не запускался) - "
              "считаю заново.")
        return None
    try:
        cached = pd.read_pickle(cache_path)
        df, cached_dir = cached["df"], cached["images_dir"]
    except Exception as e:
        print(f"  Кэш метрик повреждён ({e}) - считаю заново.")
        return None

    if cached_dir != str(Path(images_dir).resolve()):
        print(f"  Кэш посчитан для другой директории ({cached_dir}) - "
              f"считаю заново.")
        return None
    if verbose:
        print(f"Метрики взяты из кэша режима html: {cache_path} ({len(df)} ядер)")
    return df


def save_cached_metrics(cache_path, df, images_dir):
    pd.to_pickle({"df": df, "images_dir": str(Path(images_dir).resolve())},
                 Path(cache_path))


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Отбор качественных изображений ядер (отсев расфокуса).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Режимы:
  html               посчитать метрики и сделать HTML без порогов (CSV не создаётся)
  filter             посчитать метрики, применить пороги: HTML с подсветкой + CSV
  filter_after_html  то же, но метрики берутся из кэша после режима html

Пороги правятся в блоке THRESHOLDS внутри этого файла.

Примеры:
  python to_tim_filtr.py html ~/nuclei
  python to_tim_filtr.py filter_after_html ~/nuclei
  python to_tim_filtr.py filter ~/nuclei --out ~/results
""")
    parser.add_argument("mode", choices=["html", "filter", "filter_after_html"],
                        help="что делать")
    parser.add_argument("images_dir", help="директория с изображениями ядер")
    parser.add_argument("--out", default=None,
                        help="куда сохранять результаты "
                             "(по умолчанию - папка со скриптом)")
    parser.add_argument("--recursive", action="store_true",
                        help="искать изображения и во вложенных папках")
    parser.add_argument("--quiet", action="store_true",
                        help="без прогресс-баров и подробного вывода")
    parser.add_argument("--seed", type=int, default=0,
                        help="seed для выбора примеров в отчёте (по умолчанию 0)")
    args = parser.parse_args(argv)

    verbose = not args.quiet
    random.seed(args.seed)

    out_dir = Path(args.out) if args.out else Path(__file__).resolve().parent
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path = out_dir / HTML_NAME
    csv_path = out_dir / CSV_NAME
    cache_path = out_dir / CACHE_NAME

    print("=" * 70)
    print(f"Режим: {args.mode}")
    print(f"Изображения: {Path(args.images_dir).resolve()}")
    print(f"Результаты:  {out_dir}")
    print("=" * 70)

    # --- Метрики ---
    df = None
    if args.mode == "filter_after_html":
        df = load_cached_metrics(cache_path, args.images_dir, verbose)
    if df is None:
        df = compute_all_metrics(args.images_dir, args.recursive, verbose)
        save_cached_metrics(cache_path, df, args.images_dir)

    # --- Фильтрация ---
    if args.mode == "html":
        thresholds = None
    else:
        df, stats = apply_thresholds(df, verbose=True)
        thresholds = {m: THRESHOLDS.get(m) for m in METRIC_COLS}
        df.to_csv(csv_path, index=False)
        print(f"\nТаблица: {csv_path}")

    # --- Отчёт ---
    print("\nСобираю HTML-отчёт...")
    build_html_report(df, html_path, thresholds=thresholds,
                      source_dir=Path(args.images_dir).resolve(), verbose=verbose)

    print("\nГотово.")
    if args.mode == "html":
        print(f"  1. Откройте {html_path}")
        print("  2. Впишите пороги в блок THRESHOLDS в этом скрипте")
        print(f"  3. python {Path(__file__).name} filter_after_html {args.images_dir}")


if __name__ == "__main__":
    main()
