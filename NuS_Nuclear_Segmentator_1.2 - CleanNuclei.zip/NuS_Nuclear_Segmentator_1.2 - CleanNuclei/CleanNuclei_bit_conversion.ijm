dir0 = getDirectory("Working folder");
print(dir0);

dir5 = dir0 + "e-nuclei\\";

norm  = dir0 + "z1-normalized\\";
no_bg  = dir0 + "z2-no_background\\";
no_bg_hor = dir0 + "z3-no_background_horizontal\\";
// ---------------- create folders if missing ----------------
// File.makeDirectory only creates the folder (and parents) if it
// does not already exist -> safe to call on every run.
folders = newArray( norm, no_bg, no_bg_hor
);

for (i = 0; i < folders.length; i++) {
    if (!File.exists(folders[i])) {
        File.makeDirectory(folders[i]);
        print("Created: " + folders[i]);
    } else {
        print("Exists : " + folders[i]);
    }
}
print("All folders are ready.");
// ---------- configuration ----------
ball_size = 30;                 // rolling-ball radius (pixels) for background subtraction
                                // originally hard-coded as rolling=30

if (!File.exists(norm))  File.makeDirectory(norm);
if (!File.exists(no_bg))  File.makeDirectory(no_bg);
if (!File.exists(no_bg_hor)) File.makeDirectory(no_bg_hor);

// ---------- helper ----------
function contains(array, value) {
    for (var k = 0; k < array.length; k++)
        if (array[k] == value) return true;
    return false;
}

// ============================================================
// Stage 1 : 8-bit + normalization  ->  norm
// ============================================================
print("\n--- Stage 1 : 8-bit normalization ---");
list         = getFileList(dir5);
existing_eq  = getFileList(norm);
setBatchMode("hide");
saved = 0; skipped = 0;
for (i = 0; i < list.length; i++) {
    title = list[i];
    if (contains(existing_eq, title)) {
        print(title + " already in f-nuclei-8bit, skipping.");
        skipped++;
        continue;
    }
    open(dir5 + list[i]);
    title = getTitle();
    run("Enhance Contrast...", "saturated=0.0 normalize");
    run("8-bit");
    saveAs("Tiff", norm + title);
    run("Close All");
    saved++;
}
print("8-bit normalization: " + saved + " saved, " + skipped + " skipped.");
eq_saved = saved; eq_skipped = skipped;

// ============================================================
// Stage 2 : background removal  ->  no_bg
// ============================================================
print("\n--- Stage 2 : background removal (ball_size = " + ball_size + ") ---");
setBatchMode(true);
list         = getFileList(dir5);
existing_bg  = getFileList(no_bg);
saved = 0; skipped = 0;
for (i = 0; i < list.length; i++) {
    if (contains(existing_bg, list[i])) {
        print(list[i] + " already in #4b-no-background, skipping.");
        skipped++;
        continue;
    }
    open(dir5 + list[i]);
    image_name = getTitle();
    setMinAndMax(0, 65535);
    print(image_name);
    selectImage(image_name);

    run("Select None");
    run("Duplicate...", "title=bg");
    setMinAndMax(0, 65535);
    run("8-bit");

    setAutoThreshold("Moments dark no-reset");
    run("Create Selection");

    run("Set Measurements...", "area mean standard modal min center perimeter bounding fit shape median redirect=None decimal=2");
    run("Measure");
    median = (getValue("Median"));
    run("Make Inverse");

    run("Min...", "value=" + median);
    run("Select None");
    run("Subtract Background...", "rolling=" + ball_size + " create sliding");   // <-- ball_size used here
    run("16-bit");
    setMinAndMax(0, 65535);
    run("Multiply...", "value=256");

    imageCalculator("Subtract create", image_name, "bg");
    selectImage(image_name);
    close();
    selectImage("Result of " + image_name);
    rename(image_name);

    run("Enhance Contrast", "saturated=0.35 normalize");
    run("Apply LUT");
//    run("Gaussian Blur...", "sigma=1");
	
    run("Apply LUT");
    run("8-bit");
    saveAs("Tiff", no_bg + image_name);
    run("Close All");
    saved++;
}
print("Background removal: " + saved + " saved, " + skipped + " skipped.");
bg_saved = saved; bg_skipped = skipped;

// ============================================================
// Stage 3 : horizontal rotation  ->  no_bg_hor
// ============================================================
print("\n--- Stage 3 : horizontal rotation ---");
setBatchMode(true);
run("Set Measurements...", "area mean standard modal min center perimeter bounding fit shape median redirect=None decimal=2");

list_bg      = getFileList(no_bg);
existing_hor = getFileList(no_bg_hor);
saved = 0; skipped = 0;
for (i = 0; i < list_bg.length; i++) {
    if (contains(existing_hor, list_bg[i])) {
        print(list_bg[i] + " already in #5a-horizontal, skipping.");
        skipped++;
        continue;
    }
    open(no_bg + list_bg[i]);
    image_name = getTitle();
    selectImage(image_name);

    run("Select None");
    setAutoThreshold("MinError dark no-reset");
    run("Create Selection");
    run("Convex Hull");
    run("Measure");
    angle  = getValue("Angle");
    angle1 = parseInt(angle);
    run("Select None");
    run("Rotate... ", "angle=" + angle1 + " grid=1 interpolation=Bilinear enlarge");

    resetThreshold;
    setAutoThreshold("MinError dark no-reset");
    run("Create Selection");
    run("To Bounding Box");
    run("Crop");
    run("8-bit");
    saveAs("Tiff", no_bg_hor + image_name);
    run("Close All");
    saved++;
}
print("Horizontal rotation: " + saved + " saved, " + skipped + " skipped.");
hor_saved = saved; hor_skipped = skipped;

// ============================================================
// Summary
// ============================================================
setBatchMode(false);
print("\n==================== SUMMARY ====================");
print("  ball_size (background) : " + ball_size);
print("  8-bit normalization    : " + eq_saved  + " saved, " + eq_skipped  + " skipped");
print("  Background removal     : " + bg_saved  + " saved, " + bg_skipped  + " skipped");
print("  Horizontal rotation    : " + hor_saved + " saved, " + hor_skipped + " skipped");
print("=================================================");